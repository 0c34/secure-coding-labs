package com.app.vulnapps;

import E0.D;
import E0.View$OnClickListenerC0000a;
import J.H;
import J.T;
import P0.c;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.activity.l;
import e.AbstractActivityC0114h;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public final class MainActivity extends AbstractActivityC0114h {

    /* renamed from: z  reason: collision with root package name */
    public static final /* synthetic */ int f1649z = 0;

    /* renamed from: v  reason: collision with root package name */
    public EditText f1650v;

    /* renamed from: w  reason: collision with root package name */
    public EditText f1651w;

    /* renamed from: x  reason: collision with root package name */
    public Button f1652x;

    /* renamed from: y  reason: collision with root package name */
    public SharedPreferences f1653y;

    @Override // e.AbstractActivityC0114h, androidx.activity.k, y.f, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        l.a(this);
        setContentView(R.layout.activity_main);
        View findViewById = findViewById(R.id.main);
        D d2 = new D(1);
        WeakHashMap weakHashMap = T.f407a;
        H.u(findViewById, d2);
        View findViewById2 = findViewById(R.id.username_input);
        c.d(findViewById2, "findViewById(...)");
        this.f1650v = (EditText) findViewById2;
        View findViewById3 = findViewById(R.id.password_input);
        c.d(findViewById3, "findViewById(...)");
        this.f1651w = (EditText) findViewById3;
        View findViewById4 = findViewById(R.id.logn_btn);
        c.d(findViewById4, "findViewById(...)");
        this.f1652x = (Button) findViewById4;
        SharedPreferences sharedPreferences = getSharedPreferences("AppPrefs", 0);
        c.d(sharedPreferences, "getSharedPreferences(...)");
        this.f1653y = sharedPreferences;
        Button button = this.f1652x;
        if (button != null) {
            button.setOnClickListener(new View$OnClickListenerC0000a(4, this));
        } else {
            c.g("loginBtn");
            throw null;
        }
    }
}