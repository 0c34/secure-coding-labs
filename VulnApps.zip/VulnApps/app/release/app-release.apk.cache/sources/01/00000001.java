package com.app.vulnapps;

import E0.D;
import J.H;
import J.T;
import android.os.Bundle;
import android.view.View;
import androidx.activity.l;
import e.AbstractActivityC0114h;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public final class SuccessActivity extends AbstractActivityC0114h {

    /* renamed from: v  reason: collision with root package name */
    public static final /* synthetic */ int f1654v = 0;

    @Override // e.AbstractActivityC0114h, androidx.activity.k, y.f, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        l.a(this);
        setContentView(R.layout.activity_success);
        View findViewById = findViewById(R.id.main);
        D d2 = new D(2);
        WeakHashMap weakHashMap = T.f407a;
        H.u(findViewById, d2);
    }
}