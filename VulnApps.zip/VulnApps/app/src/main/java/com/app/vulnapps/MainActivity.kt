package com.app.vulnapps


import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent


class MainActivity : AppCompatActivity() {
    lateinit var usernameInput : EditText
    lateinit var passwordInput : EditText
    lateinit var loginBtn: Button
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        usernameInput = findViewById(R.id.username_input)
        passwordInput = findViewById(R.id.password_input)
        loginBtn = findViewById(R.id.logn_btn)

        sharedPreferences = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)

        loginBtn.setOnClickListener{
            val username = usernameInput.text.toString()
            val password = passwordInput.text.toString()
            login(username,password)
            Log.i("Test credentials", "Username: $username and Password: $password")
        }
    }
    private fun login(username: String, password: String) {
        val urlString = "http://10.0.2.2/get-token"  // Use 10.0.2.2 for localhost in Android emulator
        val jsonInputString = JSONObject().apply {
            put("email", username)
            put("password", password)
        }.toString()

        Thread {
            try {
                val url = URL(urlString)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json")
                connection.doOutput = true

                // Send login data
                OutputStreamWriter(connection.outputStream).use { writer ->
                    writer.write(jsonInputString)
                }

                // Read the response
                val responseCode = connection.responseCode
                val responseMessage = StringBuilder()

                BufferedReader(InputStreamReader(connection.inputStream)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        responseMessage.append(line)
                    }
                }

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val jsonResponse = JSONObject(responseMessage.toString())
                    val token = jsonResponse.getString("token") // Adjust this based on your backend response structure
                    val dataObject = jsonResponse.getJSONObject("data")
                    val userId = dataObject.getInt("user_id")
                    val phoneNumber = dataObject.getString("phone_number")
                    val userEmail = dataObject.getString("user_email")

                    Log.i("Response", "Login Response: $jsonResponse")
                    // Log the token for testing
                    //Log.i("Login", "Token received: $token")

                    // Store token in SharedPreferences
                    sharedPreferences.edit().apply {
                        putString("auth_token", token)
                        putInt("user_id",userId)
                        putString("phone_number", phoneNumber)
                        putString("email", userEmail)
                        apply()
                    }
                    val intent = Intent(this, SuccessActivity::class.java)
                    startActivity(intent)
                    finish()

                    runOnUiThread {
                        Log.i("Login", "Login successful!")
                    }
                } else {
                    Log.i("Login", "Login failed! Response Code: $responseCode")
                }

            } catch (e: Exception) {
                Log.e("Login", "Error: ${e.message}")
            }
        }.start()
    }
}
